<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['facebook']['app_id'] = ''; //masukkan app id disini
$config['facebook']['app_secret'] = ''; //masukkan app secret disini
$config['facebook']['default_graph_version'] = 'v2.10';